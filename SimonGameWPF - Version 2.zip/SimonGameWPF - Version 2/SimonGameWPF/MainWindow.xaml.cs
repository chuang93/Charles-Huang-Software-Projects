﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SimonGameWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int numPlayers;
        SoundPlayer player;
        public  MainWindow()
        {
            numPlayers = 0;
            InitializeComponent();
            Storyboard trigger = (Storyboard)this.FindResource("movingButtons");
            trigger.RepeatBehavior = RepeatBehavior.Forever;
            trigger.Begin();
            
            playBeginningSound();
               
          
        }

        private void playBeginningSound()
        {
            player = new SoundPlayer();
            player.SoundLocation = "C:\\Users\\Charles Huang\\Documents\\Simon Game\\SimonGameWPF - Version 2\\SimonGameWPF\\finalCountdown.wav";
            player.PlayLooping();
        }
        private void StartButton(object sender, RoutedEventArgs e)
        {
            
            if (setNumberOfPlayers(numPlayersBox.Text)){
                player.Stop();
                GameWindow win1 = new GameWindow(numPlayers);
                this.Close();
                win1.Show();     
                
            }
            else
            {
                MessageBoxResult result = MessageBox.Show("MUST BE A POSITIVE INTEGER FOR NUMBER OF PLAYERS");
            }
        }

        private Boolean setNumberOfPlayers(String inputNumber)
        {
            Boolean isNUm = int.TryParse(inputNumber, out numPlayers);
            return (isNUm && numPlayers>0);
        }
    }
}
