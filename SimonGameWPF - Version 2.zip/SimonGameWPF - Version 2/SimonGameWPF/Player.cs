﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimonGameWPF
{
    public class Player
    {
        public int ID;
        public int highScore;
        public int currentScore;
        public Boolean stillPlaying;
        public List<int> scores;
        public Queue<int> playerSequence;
        public Player(int nextID)
        {
            this.ID = nextID;
            this.highScore = 0;
            this.currentScore = 0;
            this.stillPlaying = true;
            this.scores = new List<int>();
            this.playerSequence = new Queue<int>();
        }
    }
}
