﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SimonGameWPF
{   
    /// <summary>
    /// Interaction logic for GameWindow.xaml
    /// </summary>
    public partial class GameWindow : Window
    {
        SoundPlayer sound;
        enum Days { Red = 1, Green, Blue, Yellow};
        public int numPlayers;
        Queue<int> tempSequence; 
        private Queue<Player> _playersIn;
        int maxScore;
        
        Dictionary<int,List<int>> finalPlayerScores;
        private Player _currentPlayer;

        public Player currentPlayer
        {
            get { return _currentPlayer; }
            set
            {
                if (value == _currentPlayer) return;
                _currentPlayer = value;
                updateCurrentPlayerText();
            }
        }

        Storyboard trigger;
        Boolean isPlayBack;
        Boolean playAgain;
        Boolean seeScores;
        Boolean notTriggered;
        int level;

        public GameWindow(int playerNum)
          
        {
            InitializeComponent();
            numPlayers = playerNum;
            notTriggered = true;
            isPlayBack = true;
            level = 1;
            playAgain = true;
            seeScores = false;
            _playersIn = new Queue<Player>();
            createPlayers(numPlayers);
            finalPlayerScores = new Dictionary<int, List<int>>();
            maxScore = 0;
        }

     
        private void createPlayers(int numPlayers)
        {
            for (int i = 0; i < numPlayers; i++)
            {
                Player newPlayer = new Player(i + 1);
                
                _playersIn.Enqueue(newPlayer);
            }
            updateActivePlayers();
        }

        private void backgroundFlash()
        {
            Storyboard s;
            s = (Storyboard)this.FindResource("background Story");
            s.Begin();
        }
        private void redbuttonclick(object sender, MouseButtonEventArgs e)
        {
            if (!isPlayBack && playAgain)
            {   isCorrectButton((int)Days.Red);
                redButtonFlash();
            }
        }

        private void redButtonFlash()
        {           
            Storyboard s;
            s = (Storyboard)this.FindResource("buttonred");
            s.Begin();            
        }

       
        private void greenbuttonclick(object sender, MouseButtonEventArgs e)
        {
            if (!isPlayBack && playAgain)
            {
                isCorrectButton((int)Days.Green);
                greenButtonFlash();
            }
        }

        private void greenButtonFlash()
        {          
            Storyboard s;
            s = (Storyboard)this.FindResource("buttongreen");
            s.Begin();
        }

        private void bluebuttonclick(object sender, MouseButtonEventArgs e)
        {   if (!isPlayBack && playAgain)
            {
                isCorrectButton((int)Days.Blue);
                blueButtonFlash();
            }
        }

        private void blueButtonFlash()
        {         
            Storyboard s;
            s = (Storyboard)this.FindResource("buttonblue");
            s.Begin();           
        }

        private void yellowbuttonclick(object sender, MouseButtonEventArgs e)
        {
            if (!isPlayBack && playAgain)
            {  
                
                    isCorrectButton((int)Days.Yellow);
                    yellowButtonFlash();
                
            }
        }

        private void yellowButtonFlash()
        {
            
            Storyboard s;
            s = (Storyboard)this.FindResource("buttonyellow");
            s.Begin();          
        }

        private void buttonMoving()
        {
            
            trigger = (Storyboard)this.FindResource("movingGame");
            trigger.RepeatBehavior = RepeatBehavior.Forever;
            trigger.Begin();
        }
        private void playColor(int colorCode)
        { // 1,2,3,4 ==> red,green,blue,yellow
            switch (colorCode)
            {
                case (int)Days.Red:
                    redButtonFlash();
                    break;
                case (int)Days.Green:
                    greenButtonFlash();
                    break;
                case (int)Days.Blue:
                    blueButtonFlash();
                    break;
                case (int)Days.Yellow:
                    yellowButtonFlash();
                    break;
            }
        }

        private async void isCorrectButton(int selectedNumber)
        {
            
            if (tempSequence.Count == currentPlayer.currentScore) //correctly got through round.
            {
            // MessageBoxResult result = MessageBox.Show("PLAYER "+currentPlayer.ID +" finished level "+level);
                currentPlayer.currentScore++;
                _playersIn.Enqueue(currentPlayer);
                tempSequence = new Queue<int>();
                currentPlayer= _playersIn.Dequeue();
                if (currentPlayer.currentScore > level)//hit next player on the next round// need to level up.
                {
                    level++;
                }
                    await playAndStoreSequence(level);
                
            }
            else {//still in sequence
                int rightButton = currentPlayer.playerSequence.Dequeue();
               
                if (rightButton != selectedNumber) //current player is wrong and is eliminated
                {
                    eliminatedText.Text = "Player: " + currentPlayer.ID + ": WRONG BUTTON";
                    sound = new SoundPlayer();
                    sound.SoundLocation = "C:\\Users\\Charles Huang\\Documents\\Simon Game\\SimonGameWPF - Version 2\\SimonGameWPF\\error.wav";
                    sound.Play();
                    isPlayBack = true;
                    gameOverFlash();
                    await Task.Delay(1500);
                    
                    
                    addPlayerResults(currentPlayer);
                    if (_playersIn.Count == 0)
                    {
                        maxScore = currentPlayer.currentScore;
                        noActivePlayers();
                        gameOverFlash();
                        eliminatedText.Text = "GAME OVER D:";
;                        sound = new SoundPlayer();
                        sound.SoundLocation = "C:\\Users\\Charles Huang\\Documents\\Simon Game\\SimonGameWPF - Version 2\\SimonGameWPF\\error.wav";
                        sound.PlayLooping();
                        await Task.Delay(1500);
                        MessageBoxResult result = MessageBox.Show("GAME OVER! High Score was " + maxScore + "! SEE HISTORY OR PLAY AGAIN!");
                        level = 1;
                        playAgain = true;
                        isPlayBack = true;
                        seeScores = true;
                        _playersIn = new Queue<Player>();
                        createPlayers(numPlayers);
                        button.Content = "Play Again?";
                      
                    }
                    else
                    {
                      
                        currentPlayer = _playersIn.Dequeue();
                        tempSequence = new Queue<int>();
                        level = currentPlayer.currentScore;
                        await playAndStoreSequence(level);
                    }
                }
                else
                {
                    sound = new SoundPlayer();
                    sound.SoundLocation = "C:\\Users\\Charles Huang\\Documents\\Simon Game\\SimonGameWPF - Version 2\\SimonGameWPF\\boing.wav";
                    sound.Play();
                    tempSequence.Enqueue(rightButton);
                    if (currentPlayer.playerSequence.Count() == 0)
                    {   foreach (int queued in tempSequence)
                        {
                            currentPlayer.playerSequence.Enqueue(queued);
                        }
                       isCorrectButton(selectedNumber);
                    }
                }
            }
            updateActivePlayers();
        }

        private void gameOverFlash()
        {
                backgroundFlash();
                greenButtonFlash();
                redButtonFlash();
                blueButtonFlash();
                yellowButtonFlash();
            
        }
        private void scoreboardButtonClick(object sender, RoutedEventArgs e)
        {
            if (seeScores)
            {
                Scores winScores = new Scores(finalPlayerScores);
                this.Close();
                winScores.Show();
            }
        }

        private void addPlayerResults(Player currPlayer)
        {
            if (!finalPlayerScores.ContainsKey(currPlayer.ID))
            { List<int> currPlayerSheet = new List<int>();
                currPlayerSheet.Add(currPlayer.currentScore);
                finalPlayerScores.Add(currPlayer.ID,currPlayerSheet);
            }
            else
            {
                List<int> currPlayerSheet = finalPlayerScores[currPlayer.ID];
                currPlayerSheet.Add(currPlayer.currentScore);
                finalPlayerScores[currPlayer.ID] = currPlayerSheet;
            }
        }
        private async Task  playAndStoreSequence(int level)
        {
            
            if (level >= 5 && notTriggered)
            {
                notTriggered = false;
                buttonMoving();
            }
            currentPlayer.currentScore = level;
            isPlayBack = true;
            await Task.Delay(200);
            
            sequencetext.Text = "Sequence ";
            Random randNum = new Random();
            
                int nextNum = randNum.Next(1, 5);
                currentPlayer.playerSequence.Enqueue(nextNum);
                updateSequence(currentPlayer.playerSequence);
                await buttonSequence(currentPlayer.playerSequence,level*100);

            playAgain = true;
            isPlayBack = false;
        }


        async Task buttonSequence(Queue<int> playerSequence, int level)
        {
            
           int x=900 - level;
           if (x <= 500)
            {
               x = 500;
            }
            foreach (int y in playerSequence)
            { 
                    await Task.Delay(x);
                sound = new SoundPlayer();
                sound.SoundLocation = "C:\\Users\\Charles Huang\\Documents\\Simon Game\\SimonGameWPF - Version 2\\SimonGameWPF\\step.wav";
                sound.Play();
                playColor(y);
                }
            await Task.Delay(500);
            eliminatedText.Text = "";
        }

       private void updateSequence(Queue<int>playerSequence)
       {   
            foreach (int i in playerSequence)
            {
                sequencetext.Text += i + " | ";
            }
        }

        private void updateCurrentPlayerText()
        {
            currentPlayerText.Text ="Current Player: "+ currentPlayer.ID;
        }

        private void updateActivePlayers()
        {
            activePlayerText.Text = "Active Players: ";
            if (_playersIn.Count != 0)
            {
                foreach (Player curr in _playersIn)
                {
                    int currScore = curr.currentScore;
                    if (currScore == 0) currScore = 1;
                    activePlayerText.Text = activePlayerText.Text + System.Environment.NewLine + "Player " + curr.ID + " | " +currScore;
                }
            }
            if (currentPlayer != null && !iscurrentPlayerInPlayersIn(currentPlayer))
            {
                int currScore = currentPlayer.currentScore;
                if (currScore == 0) currScore = 1;
                activePlayerText.Text = activePlayerText.Text + System.Environment.NewLine + "Player " + currentPlayer.ID + " | "+ currentPlayer.currentScore;
            }
            
        }
        private Boolean iscurrentPlayerInPlayersIn(Player curr)
        {
            foreach (Player p in _playersIn)
            {
                if (p.ID == curr.ID)
                    return true;
            }
            return false;
        }
        private void noActivePlayers()
        {
            activePlayerText.Text = "NOONE PASSED THIS LEVEL :( ";
        }
        private async void playGameButton(object sender, RoutedEventArgs e)
        {
            
            if (sound != null)
            {
                sound.Stop();
            }
           
          
            await Task.Delay(1000);
            notTriggered = true;
            if (trigger != null)
            {
                trigger.Remove();
            }

            if (_playersIn.Count == numPlayers)
            {
                seeScores = false;

                if (playAgain == true)
                {
                    sound = new SoundPlayer();
                    sound.SoundLocation = "C:\\Users\\Charles Huang\\Documents\\Simon Game\\SimonGameWPF - Version 2\\SimonGameWPF\\intro.wav";
                    sound.Play();
                    eliminatedText.Text = "Lets Play!";
                    playAgain = false;
                    tempSequence = new Queue<int>();
                    currentPlayer = _playersIn.Dequeue();
                    await playAndStoreSequence(level);

                }

            }
        }


    }
}
