﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SimonGameWPF
{
    /// <summary>
    /// Interaction logic for Scores.xaml
    /// </summary>
    public partial class Scores : Window
    {
        Dictionary<int,List<int>> finalPlayers;
        public Scores(Dictionary<int,List<int>> fPlayers)
        {
            InitializeComponent();
            this.finalPlayers = fPlayers;
            displayScoreSheet();
        }
        private void displayScoreSheet()
        {
            foreach(KeyValuePair<int,List<int>> kvp in finalPlayers)
            {
                scoreSheet.Text += "Player: " + kvp.Key + " | ";
                for (int i = 0; i < kvp.Value.Count; i++)
                {
                    scoreSheet.Text += "rd " + (i + 1) + ": " + kvp.Value[i] + "|";
                }
                scoreSheet.Text += System.Environment.NewLine;
            }
            
        }
        private void homepageClick(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            this.Close();
        }
    }
}
